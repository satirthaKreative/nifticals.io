<?php
    if(isset($_GET['send_comment'])){
        $to = $_GET['q_email'];
        $subject = 'Query email';
        $message = 'Name : '.$_GET['q_name'].', comment :'.$_GET['q_comment']; 
        $from = 'satirtha.kreative@gmail.com';
         
        
        if(mail($to, $subject, $message)){
            echo '<script>alert("Your mail has been sent successfully")</script>';
        } else{
            echo '<script>alert("Unable to send email. Please try again.")</script>';
        }
    }
if(isset($_GET['create_sender_submit']))
{
    $sender_Address = $_GET['mail_sender_address'];
    $sender_Name = $_GET['mail_sender_name'];
    if($_GET['mail_sender_phone'] == "")
    {
        $phone_number = "Phone number not mentioned";
    }
    else
    {
        $phone_number = $_GET['mail_sender_phone'];
    }
    
    if($_GET['mail_sender_image_link'] == "")
    {
        $mailing_link = "Not mentioned";
    }
    else
    {
        $mailing_link = $_GET['mail_sender_image_link'];
    }
    
    if($_GET['mail_sender_link_barcode'] == "")
    {
        $mail_sender_link = "Not mentioned";
    }
    else
    {
        $mail_sender_link = $_GET['mail_sender_link_barcode'];
    }
    
    if($_GET['mail_sender_comments'] == "")
    {
        $mail_sender_comment = "Not mentioned";
    }
    else
    {
        $mail_sender_comment = $_GET['mail_sender_comments'];
    }
    $to = $_GET['mail_sender_mail'];
    $subject = 'Product email';
    $message = 'Name : '.$sender_Name.', Address :'.$sender_Address.', Phone number :'.$phone_number.', link :'.$mailing_link.', barcode link :'.$mail_sender_link.', comment :'.$mail_sender_comment; 
    $from = 'satirtha.kreative@gmail.com';
     
    // Sending email
    if(mail($to, $subject, $message)){
        echo '<script>alert("Your mail has been sent successfully")</script>';
    } else{
        echo '<script>alert("Unable to send email. Please try again.")</script>';
    }
// 	$to = 'satirtha63@gmail.com';
// 	$subject = 'Product Mail';
// 	$from = 'satirtha.kreative@gmail.com';
	
// 	// To send HTML mail, the Content-type header must be set
// 	$headers  = 'MIME-Version: 1.0' . "\r\n";
// 	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
	
// 	// Create email headers
// 	$headers .= 'From: '.$from."\r\n".
// 		'Reply-To: '.$to."\r\n" .
// 		'X-Mailer: PHP/' . phpversion();
	
// 	// Compose a simple HTML email message
// 	$message = '<html><body>';
// 	$message .= '<h1 style="color:#f40;">Hi Jane!</h1>';
// 	$message .= '<p style="color:#080;font-size:18px;">Html Data Send Successfully</p>';
// 	$message .= '</body></html>';
	
// 	// Sending email
// 	if(mail($to, $subject, $message, $headers)){
// 		echo '<script>alert("Your mail has been sent successfully")</script>';
// 	} else{
// 		echo '<script>alert("Unable to send email. Please try again.")</script>';
// 	}
}

?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Home</title>
		
		<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
		<link href="css/style.css" rel="stylesheet" type="text/css">
		<link href="css/responsive.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
		<link rel="stylesheet" href="css/owl.theme.default.css" type="text/css">
		<link rel="stylesheet" href="css/slimNav_sk78.css">
		<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    
	</head>
	<body>
		<header>
			<div class="modal fade search-hold" id="myModal" role="dialog">
				<div class="modal-dialog">
					<!-- Modal content-->
					<div class="modal-content">
						<div class="modal-body">
							<form action="">
								<input type="text" name="" placeholder="Search...">
							</form>
						</div>
					</div>
					
				</div>
			</div>
			<div class="header_mid">
				<div class="container">
					<div class="row">
						<div class="col-md-3 col-sm-3 logo_con">
							<a href="index.php"><img src="images/logo.png" alt=""></a>
						</div>
						<div class="col-md-9 col-sm-9">
							<div class="menu-part">
								<div id="navigation">
									<nav>
										<ul>
											<li class="current-menu-item"><a href="index.php">Home </a></li>
											<li><a href="product.php">Products</a>
												<!-- <ul class="sub-menu">
													<li><a href="#">Birthday Party</a></li>
													<li><a href="#">Wedding Ceremony</a></li>
												</ul> -->
											</li>
											<li><a href="categories.php">Categories</a>
											</li>
											<li><a href="contact.php">Contact</a></li>

										</ul>
									</nav>
								</div>
							</div>
							<div class="header_rihgt">
								<ul>
									<li><a href="#" data-toggle="modal" data-target="#myModal"><i class="fa fa-search"></i></a></li>
									<li><a href="#"><i class="fa fa-shopping-cart"></i><span>0</span></a></li>
									<li>
										<a class="join" href="join.php">Join Us</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</header>
		 
		  <!-- The Modal -->
  <div class="modal fade" id="myModal2">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>        
        <!-- Modal body -->
        <div class="modal-body">
          <div class="row">
              <div class="col-lg-6 p-0">
                  <img src="images/cust-img.jpg" alt="">
              </div>
              <div class="col-lg-6">
                  <h3>Create Your Custom Print, Today !!</h3>
                  <form action="" id="main-email-post-id" method="GET" enctype="multipart/form-data">
                      <input type="text" required id="mail-sender-name-id" name="mail_sender_name" placeholder="Name">
                      <input type="text" required id="mail-sender-address-id" name="mail_sender_address" placeholder="Address">
                      <input type="text" required id="mail-sender-email-id" name="mail_sender_mail" placeholder="Email ">
                      <input type="text" name="mail_sender_phone" placeholder="Phone (Optional)">
                      <input type="text" name="mail_sender_image_link" placeholder="Link to image (Optional)">
                      <input type="text" name="mail_sender_link_barcode" placeholder="Link to site to be placed on QR code">
                      <div class="field" align="left">
                        <img src="images/file-icon.svg">
                          <h4>Choose a file or drag it here</h4>
                          <input type="file" id="files" name="files[]" multiple />
                        </div>
                      <textarea id="mail-sender-comment-id" name="mail_sender_comments" placeholder="Comments"></textarea>
                      <input type="submit" name="create_sender_submit" id="send-mail-id" value="Create">
                  </form>
              </div>
          </div>
        </div>        
      </div>
    </div>
  </div>
